# Architecture: RWA Voting and Polls

## 1. Scope and governing decisions

[PRD.md](./PRD.md) defines product behavior and [DESIGN.md](./DESIGN.md) defines UX and visual behavior. This document defines their implementation; it does not override them.

Build a single mobile-first web application for one RWA, initially supporting 500 eligible households and 100 concurrent users. Use one application deployment, one PostgreSQL database, and transactional email. Do not introduce microservices, a separate SPA/backend pair, a queue, Redis, object storage, or AI for the MVP.

**OPEN VOTING** and **CLOSED VOTING** are voting types, independent of **Draft**, **Active**, **Completed**, and **Cancelled** lifecycle states.

Implement PRD assumptions A1-A7 provisionally, but obtain explicit approval before production:

- One designated adult representative casts one vote per household.
- CLOSED VOTING provides application-level privacy, not cryptographic anonymity against infrastructure operators.
- OPEN VOTING identities and all choice totals become visible only after completion.
- Identity is verified through codes sent to registered email addresses.
- Elections are single-selection per office, with explicit abstention and highest-vote-wins counting; polls are single-choice. No quorum or approval threshold is inferred.
- Approve retention, deletion, backup expiry, and launch capacity.
- A PDF is a decision record, not an electronic signature, legal certification, or automatic replacement for legally required signatures.

Provider selection, hosting region, and data-processing arrangements also require approval. Do not silently weaken these decisions to accommodate a provider.

## 2. Recommended technology stack

| Concern | Recommendation | Reason |
|---|---|---|
| Application | TypeScript, React, Next.js App Router on a supported Node.js LTS release | One deployment and language for responsive pages and server endpoints; no separate backend infrastructure. |
| Styling | CSS Modules, shared CSS design tokens, native HTML controls | Direct implementation of DESIGN.md without a large component framework. |
| Database | Managed PostgreSQL with encrypted storage and backups | Transactions, constraints, row locking, and durable counters support voting integrity. |
| Database access | `pg` with parameterized SQL and versioned SQL migrations | Makes locking and privacy-critical transactions explicit; avoids an ORM abstraction over the central correctness mechanism. |
| Input validation | Zod | Shared request schemas and clear server-side validation, without treating browser validation as authoritative. |
| Authentication | Server-managed opaque sessions and email OTP challenges | Fits registered-member access without a separate identity service or browser-stored tokens. |
| Email | One approved transactional email provider through its HTTPS API | The only required outbound user communication. |
| PDF | PDFKit running inside the application | Generates real downloadable PDFs on mobile and desktop without an external PDF service or headless browser. |
| Tests | Vitest, Playwright, and axe integration | Unit, real-database integration, browser, and automated accessibility coverage. |
| Hosting | Managed HTTPS container service and managed PostgreSQL in the same approved region | Supports a persistent Node process, PDF generation, bounded connection pooling, and scheduled maintenance without operating a cluster. |

Pin dependency versions in a lockfile. Select supported releases at implementation time, review licenses and advisories, and use only the dependencies needed for these responsibilities.

No AI model, vector database, chatbot, or external analytics platform is needed. Counting, eligibility, authorization, and report generation must remain deterministic.

## 3. Application architecture and boundaries

Use a **modular monolith**:

1. **Presentation:** Next.js pages, layouts, accessible forms, review/confirmation, and download controls.
2. **HTTP boundary:** Same-origin route handlers authenticate, validate input, enforce CSRF protection, and translate domain outcomes into HTTP responses.
3. **Application services:** Register management, authorization, lifecycle actions, submissions, results, exports, and audit coordination.
4. **Persistence:** Parameterized repositories, migrations, constraints, and narrowly scoped database routines for protected voting operations.
5. **Adapters:** Email delivery, PDF rendering, clock-independent formatting, and operational logging.

Server-render initial page data through the same application services used by route handlers; do not issue internal HTTP requests to the application itself. Client components handle interactive forms and request feedback. Keep database clients, secrets, and protected services in server-only modules.

Authorization belongs in services and protected database operations, not just navigation, middleware, or hidden buttons. Never serialize a full database entity into a page and rely on the UI to conceal fields.

### Frontend behavior

- Share one application shell between member and administrator routes, with clearly identified administration navigation.
- Implement the design tokens, separate type/status badges, privacy notices, native radio groups, explicit review, and final confirmation from DESIGN.md.
- Keep unsent ballot choices in page memory only: no URLs, local storage, session storage, offline cache, service worker, or persistent draft ballot.
- Clear selections after confirmed submission, sign-out, or access revocation. CLOSED VOTING acknowledgements show participation only, not selections.
- Disable duplicate clicks for UX, but rely on the database for duplicate prevention.
- Do not optimistically acknowledge submissions, show live totals, or prefetch protected results.
- Set authenticated pages and responses to `Cache-Control: private, no-store`; do not use shared framework/CDN caches for member data.
- Meet WCAG 2.2 AA, 44-by-44 CSS-pixel targets, keyboard/focus requirements, reduced motion, and the specified 320-430 and 1280-1440 CSS-pixel layouts.

## 4. Suggested folder structure

```text
docs\
  PRD.md
  DESIGN.md
  ARCHITECTURE.md
src\
  app\
    (access)\
    (member)\
    admin\
    api\
      auth\
      votes\
      admin\
      internal\
  components\
    ui\
    votes\
    admin\
  styles\
  shared\
    contracts\
    validation\
  server\
    auth\
    authorization\
    register\
    votes\
    results\
    exports\
    audit\
    db\
    email\
    observability\
    config\
db\
  migrations\
tests\
  unit\
  integration\
  e2e\
  fixtures\
public\
  fonts\
```

Group related services, repositories, and types inside each server feature. Do not create generic repository frameworks, dependency-injection containers, or separate packages for the MVP. Route groups organize pages without becoming URL segments.

## 5. Data model and database interaction

Use stable internal IDs, foreign keys, explicit check constraints, and UTC `timestamptz` values. Store the RWA's IANA timezone for input and display. The database clock is authoritative for voting deadlines.

| Record | Purpose and important constraints |
|---|---|
| `rwa_settings` | Singleton RWA name, timezone, approved policy versions, and retention settings. |
| `accounts` | Unique normalized registered email, representative name, account status, and administrator role. No public registration. |
| `households` | Unique normalized household identifier, eligibility, and current representative account. A unique representative assignment prevents ambiguous household entitlements under A1. |
| `auth_challenges` | Expiring keyed code digest, challenge identifier, attempt count, delivery state, and consumed state. |
| `sessions` | Digest of random session token, account, expiry, and revocation state. |
| `votes` | Type, separate lifecycle state, title/question, instructions/context, frozen deadline, activation/effective completion timestamps, cancellation metadata, and draft revision. |
| `offices`, `candidates`, `poll_options` | Ordered ballot configuration. Foreign keys bind candidates to their office and choices to their vote. |
| `electorate` | Unique `(vote_id, household_id)`, frozen representative account, representative name and household-label snapshots. |
| `participation` | Unique electorate entitlement; records only that submission was accepted, never CLOSED VOTING selections. |
| `open_responses` | One selected poll option per participating entitlement; identity is resolved from the frozen electorate, not the current register. |
| `closed_tallies` | One cumulative counter per vote/office/candidate, plus an abstention counter per office. No identity, ballot ID, response row, or per-response timestamp. |
| `audit_events` | Actor, administrative action, affected record, time, and required reason; no authentication secrets or CLOSED VOTING choices. |
| `rate_limit_buckets` | Short-lived atomic counters for shared authentication and sensitive-endpoint limits. |

Keep accounts referenced by historical electorates stable; use suspension and soft deletion until the approved retention process permits removal. Updating the current register must not rewrite frozen electorate snapshots. Representative reassignment applies only to future votes; emergency suspension blocks the original account without transferring an active entitlement.

### Persistence rules

- Use a bounded PostgreSQL pool and short transactions; never hold a transaction open during email delivery or PDF generation.
- Use parameterized SQL exclusively. Allowlist sort fields and pagination bounds.
- Use database constraints for uniqueness, valid states, nonnegative counters, and referential consistency, including option/office ownership.
- Validate and freeze ballot content, electorate, deadline, and relevant RWA display metadata atomically on activation. Do not maintain an independently editable results dataset.
- Restrict active/completed/cancelled configuration writes through database guards as well as service checks.
- Use a separate migration owner and a non-owner runtime role. Runtime credentials cannot perform DDL, grant privileges, or update audit history.
- Deny runtime direct access to `closed_tallies`. Grant execution only on narrow submission and completion-gated results routines. Their owner is a non-login role; revoke public execution, fix the search path, avoid dynamic SQL, and validate all arguments.
- Services derive the account ID from the verified session; neither account identity nor household entitlement is trusted from a request body.

## 6. CLOSED VOTING privacy and atomic submission

**Store aggregate counters, not individual closed ballots.** This is the simplest representation that supports final totals while avoiding ordinary stored identity-to-choice records. It intentionally cannot support individual recounts or ballot retrieval.

Each final submission executes one protected database operation:

1. Lock the vote row, using the same lock order as lifecycle operations.
2. Recheck account suspension, frozen representative entitlement, type, lifecycle, and the current database clock after acquiring the lock. Require Active status and time strictly before the deadline.
3. Check existing participation. If already submitted, return a participation-only conflict without changing data.
4. Validate exactly one selection or explicit abstention for every configured office, rejecting foreign candidates, omitted offices, repeated offices, and extra input.
5. Insert the unique participation record and increment the selected candidate/abstention counters for all offices in the same transaction.
6. Commit durably before acknowledging success. Return only the member's submitted status.

Any validation, constraint, timeout, or database failure rolls back participation and every counter update together. Unique constraints remain the last defense against retries and concurrent sessions. Acquire office/counter locks in stable order.

OPEN VOTING uses the same locking, deadline, entitlement, and participation rules, but atomically inserts one attributable response rather than closed counters.

Per-vote serialization is deliberate at MVP scale: it simplifies duplicate prevention, deadline checks, and completion races. Load-test it against the required acknowledgement threshold before launch.

### Explicit privacy limits

- No closed ballot rows, cross-office ballot IDs, selection-bearing receipts, request-body logs, SQL bind-parameter logs, or per-response counter history.
- Do not expose active counter snapshots, query endpoints, change feeds, monitoring dashboards, or debug tools that permit tally differencing. Administrators may inspect participation, not tally storage.
- Participation and audit records must not carry choices or a shared identifier with choice data. There is no CLOSED VOTING selection-retrieval endpoint.
- Disable payload capture in the application, proxy, error tracker, APM, and database statement instrumentation for voting and authentication paths.
- Database WAL, point-in-time backups, privileged instrumentation, and a compromised application process can reveal transaction relationships or counter changes. Operators with those capabilities are outside A2's application-user privacy boundary.
- Low-turnout aggregates can permit inference even without stored mappings. Do not promise mathematical anonymity or introduce unapproved suppression that changes required results.

Document and obtain approval for these limitations before using real election data. Stronger secrecy would require a separately designed cryptographic election system, not a future toggle on this schema.

## 7. Lifecycle, data flow, and counting

### Setup and activation

Administrator edits a draft, selects its voting type, configures the ballot/electorate/deadline, and previews the resident experience. Draft writes use revision checks to prevent lost updates. Activation includes the previewed revision; the server rejects stale confirmation, revalidates the full draft, snapshots the electorate and metadata, initializes counters, records activation, and writes the audit event atomically.

Supported transitions are Draft to Active, Active to Completed, and Active to Cancelled only. Voting type never changes as a consequence of status.

### Participation and uncertainty

Member signs in, loads an authorized ballot, selects and reviews choices, explicitly confirms, and submits. The response confirms participation only after commit. If the connection fails or times out, the UI checks the member's participation endpoint before offering a retry. If that check also fails, retain an explicit unknown state; do not claim rejection or success.

### Deadline completion and early completion

- A scheduled maintenance invocation completes due votes at least once per minute. Authorized vote reads and submission handling also reconcile overdue state, so scheduler downtime cannot keep voting open.
- Reconciliation uses the same vote-row lock and is idempotent. For deadline completion, the effective completion timestamp is the deadline, not the scheduler execution time.
- Submission admission is checked after the lock is acquired. Requests arriving at or after the deadline are always rejected; an earlier request that waits past the cutoff may also be rejected. Do not use a browser clock or a transaction-start timestamp for this decision.
- Early completion requires explicit confirmation and a reason. Cancellation requires a reason and may occur only while Active and before automatic deadline completion. Reconcile overdue state before lifecycle decisions.
- Terminal votes cannot reopen. Incorrect active votes are cancelled and replaced, never silently edited. Outages do not extend frozen deadlines.

### Results and invariants

Completion and cancellation serialize against submission. Completed results are immutable. Read results in a consistent database snapshot; the same authoritative result projection feeds the page, CSV, and PDF.

- Eligible count is the frozen electorate size, including representatives later suspended.
- Submitted count is accepted participation. Turnout is submitted divided by eligible households, with explicit denominators.
- For each election office, candidate counts plus abstentions must equal submitted ballots. Candidate and abstention percentages use submitted ballots.
- For a poll, option counts and named-response count must equal submitted ballots; percentages use submitted responses.
- Highest candidate count determines the leader per office; equally highest positive counts are a tie. Zero ballots or an all-abstention office has no winner. Polls report counts without inferring legal authority or spending approval.
- Zero denominators produce an explicit no-votes state, never invalid arithmetic. Apply one shared rounding policy and do not alter raw counts to force rounded percentages to sum to 100.
- Reconcile invariants before publishing completed results. A mismatch blocks publication/exports and triggers an operational alert; never fabricate or silently repair totals.
- Cancelled votes show "Cancelled; results not valid" and publish neither choices nor results exports.

## 8. Authentication and authorization

### Registered-email authentication

1. Normalize email using one documented policy; do not apply provider-specific address rewriting. Only administrator-provisioned, enabled accounts can authenticate.
2. Accept code requests through a uniformly worded response that does not disclose registration. Record delivery failures operationally; show generic recovery guidance without revealing whether an address exists.
3. Generate an eight-digit code with a cryptographically secure random generator. Bind it to an opaque challenge and email; expire it after ten minutes. Store only a keyed digest, never the code.
4. Allow at most five failed verification attempts per challenge. Enforce resend cooldown and shared per-email and trusted-client-IP limits in PostgreSQL. Supersede prior challenges when issuing a replacement.
5. Send email outside database transactions. Mark provider failures explicitly; never log the code or claim that delivery is guaranteed.
6. Consume the challenge atomically on successful verification. Create a cryptographically random opaque session, storing only its digest.

Use a `__Host-` session cookie with Secure, HttpOnly, SameSite=Lax, Path=/, and no Domain. Apply a 30-minute idle timeout and 12-hour absolute expiry. Rotate after authentication or privilege change; revoke on sign-out and suspension. Do not put access tokens in browser storage.

Check account status and current administrative role on each protected request, not only when the session is issued. Rate limits and expiry values are initial operational defaults to validate during the pilot.

Provision the first administrator using a controlled deployment command against an approved registered address, recording the action. Never expose a public bootstrap endpoint or default credentials.

### Permission matrix

| Action | Member | Administrator |
|---|---|---|
| View ballot and cast | Own frozen entitlement only | Own frozen entitlement only; no impersonation |
| View own participation | Yes, for accessible votes | Yes |
| Inspect others' participation | No while Active | Yes, without selections |
| Manage register/drafts/lifecycle | No | Yes |
| View/export completed results | Frozen eligible representative | Yes |
| View OPEN VOTING named responses after completion | Frozen eligible representative | Yes |
| Retrieve CLOSED VOTING individual choices | Never | Never |
| View administrative audit history | No | Yes |

Emergency suspension overrides all account access. Object-level authorization applies to every identifier and every export; possession of a URL grants no access.

## 9. API architecture

Use same-origin JSON endpoints under `/api`, validated request schemas, explicit response projections, and no GraphQL or separate public API version for the MVP.

| Endpoint | Responsibility |
|---|---|
| `POST /api/auth/code` | Request registered-email verification; generic acknowledgement. |
| `POST /api/auth/verify` | Consume code and establish session. |
| `POST /api/auth/sign-out` | Revoke session and clear cookie. |
| `GET /api/votes` | Authorized vote summaries, type, status, and own participation. |
| `GET /api/votes/{id}` | Authorized ballot/details; no active choice totals. |
| `GET /api/votes/{id}/participation` | Current member's accepted/not-submitted status. |
| `POST /api/votes/{id}/submission` | Final complete submission; participation-only acknowledgement. |
| `GET /api/votes/{id}/results` | Completed, authorized result projection. |
| `GET /api/votes/{id}/exports/{format}` | Authorized completed CSV or PDF download. |
| `/api/admin/households` and `/{id}` | Register list/create/edit through appropriate GET/POST/PATCH methods. |
| `/api/admin/votes` and `/{id}` | Administrative list/create and revision-checked draft editing. |
| `POST /api/admin/votes/{id}/{action}` | Preview validation, activation, early completion, or cancellation with explicit action schemas. |
| `GET /api/admin/votes/{id}/participation` | Participation monitoring without selections. |
| `GET /api/admin/audit` | Paginated administrative audit history. |
| `POST /api/internal/maintenance` | Scheduler-authenticated deadline completion and bounded retention cleanup. |

All mutations validate the exact allowed origin and an anti-CSRF token. Sign-in/code endpoints also require origin checks and rate limits. Downloads have no mutating side effects.

Use bounded pagination for register, audit, and named-response UI lists. Exports deliberately include the complete authorized dataset, not just the visible page.

Return consistent errors with a stable code, safe message, optional field errors, and a random support/request identifier. Use 401 for missing/expired sessions, 403 for denied capabilities, 404 for inaccessible vote IDs, 409 for duplicates/stale revisions/lifecycle conflicts, 422 for validation, 429 for rate limits, and 503 for temporary dependency failure.

Never include CLOSED VOTING choices in response echoes or validation payloads. A successful final submission returns only a participation acknowledgement; a duplicate returns `ALREADY_SUBMITTED` and directs the UI to confirm participation rather than resubmit.

## 10. External services and exports

### External boundaries

- **Email provider:** Receives the destination address and sign-in message only. No ballots, results, voter register exports, or vote selections.
- **Hosting:** Terminates HTTPS and runs the application. Restrict administrative access and disable request payload capture.
- **Managed database:** Holds authoritative records with private connectivity or a strict allowlist, TLS, encrypted disks, and encrypted backups.
- No external PDF renderer, electronic-signature provider, social login, messaging integration, remote fonts, or third-party voting-screen trackers.

### CSV and PDF generation

Authorize each download, reconcile completion, and obtain the same consistent result projection used by the results page. Generate on demand inside the application; do not persist public report files, use bearer download URLs, or email attachments.

Complete rendering in bounded memory before returning a successful PDF response. On rendering failure, return a structured error, never a partial document labeled successful. Network interruption remains a download failure and does not affect results.

PDFKit output must support A4 portrait, grayscale-safe styling, wrapped long text, repeated table headers, page numbers, and table rows that can continue across pages without clipping. Do not assume fixed-height rows. Use a redistributable font matching the UI's system-sans visual family, bundled locally with the required glyph coverage; verify actual names and scripts during the pilot.

Include RWA name, title, type, question/offices and candidates/options, activation/effective completion times with timezone, eligible/submitted counts, turnout, totals, explicit percentage denominators, abstentions/ties/no-votes, and generation time. OPEN VOTING PDFs include every respondent name, household identifier, and choice, without email addresses. CLOSED VOTING reports include aggregate counts only, never household/voter lists.

CSV uses the same authorization and privacy rules, correct escaping, and spreadsheet-formula-injection protection for user-controlled text. Use safe filenames, appropriate content types, attachment disposition, `nosniff`, and `no-store`.

Explain that downloaded/printed records cannot be remotely revoked or deleted and do not constitute signatures or legal certification. Exports must not imply spending authorization.

## 11. Environment configuration

Validate configuration at startup; fail clearly on missing or unsafe production settings.

| Configuration | Purpose |
|---|---|
| `APP_ORIGIN`, `NODE_ENV`, `PORT` | Canonical HTTPS origin, execution mode, and listener. |
| `DATABASE_URL`, `DB_POOL_MAX` | Runtime database credentials and bounded connection budget. |
| `MIGRATION_DATABASE_URL` | Deployment-only database owner credentials; unavailable to the running app. |
| `EMAIL_API_KEY`, `EMAIL_FROM` | Approved sender/provider credentials. |
| `OTP_HMAC_KEY` | Secret for keyed code digests, separate from other credentials. |
| `SCHEDULER_SECRET` | Authenticates maintenance invocation; rotate independently. |
| `LOG_LEVEL`, `TRUSTED_PROXY_CONFIG` | Safe observability and explicit source-IP trust configuration. |

Store RWA identity, timezone, approved retention settings, and policy approvals in controlled database settings, not public build variables. Production activation is blocked until required approvals are recorded. Backup expiry must also be configured with the database provider to match the approved policy.

Use local, test, staging, and production environments with separate databases, credentials, and email configuration. Local/test use synthetic identities and a local mail sink; staging uses approved test recipients. Never copy real ballots, registers, or production backups into development.

Keep secrets in the hosting secret manager, exclude local environment files from source control, and provide a placeholder-only environment example when implementing the application. Never expose database or provider credentials through browser-visible environment prefixes.

## 12. Error handling, security, and operations

### Error and recovery model

- Distinguish validation, access denial, expired authentication, lifecycle conflict, duplicate participation, transient infrastructure failure, and unknown submission outcome.
- Map expected failures to actionable UI messages. Unexpected errors produce a safe response and restricted operational alert; do not broadly catch errors and return success-shaped defaults.
- Log allowlisted event names, status classes, latency, and safe support IDs. Never log raw request bodies, cookies, tokens, codes, email content, or selection-bearing SQL parameters.
- Error trackers must scrub headers, URLs, and user input. Disable session replay and network/body capture on authenticated workflows.
- Keep PDF failures independent from voting transactions. Keep completed results visible with a retryable download error.

### Security boundaries

- Browser input is untrusted. Validate all fields and permissions server-side; enforce limits on body size, string length, list length, and export concurrency.
- Escape rendered content; do not accept rich HTML or arbitrary resource URLs. Apply a restrictive CSP, HTTPS/HSTS, frame denial, MIME protection, and a no-referrer policy.
- Keep application sessions same-origin; do not enable broad CORS. Trust forwarded IP headers only from configured hosting proxies.
- Separate database runtime, migration, and operator privileges. Application administrators are not infrastructure administrators and receive no database-console access.
- Audit administrator register, privilege, draft, activation, early-completion, cancellation, suspension, and policy changes. Record reasons where required without recording choices.
- Retention cleanup is deliberate, auditable, and lifecycle-aware. Never delete participation while a vote can accept submissions. Delete expired vote records as a coherent unit only under the approved policy; preserve required evidence for its approved period.
- Restrict backup access and expire backups according to policy. A restoration must reapply deletion/suspension records created after the restore point before normal access resumes.

### Observability and recovery

Monitor availability, database connectivity/pool saturation, submission failure rate and latency, invariant-check failures, scheduler lag, email delivery failures, and PDF failures. Alerts must not contain selections or active tally snapshots. Health endpoints expose no member data or secrets.

Maintain encrypted automated backups and a documented restore runbook. Test restoration before launch, verifying participation uniqueness and tally invariants. A backup can be internally consistent yet omit previously acknowledged submissions: do not resume an interrupted election unless accepted-data completeness is proven. If uncertain, keep access in maintenance mode and follow an approved cancellation/replacement procedure.

Record operational recovery objectives and provider backup capabilities before launch. Never promise automatic deadline extensions or unproven zero-data-loss recovery.

## 13. Testing and acceptance

| Layer | Required evidence |
|---|---|
| Unit | Input rules; role/type/state decisions; percentages/rounding; ties, all-abstention and no-votes outcomes; error mapping; report projections. |
| PostgreSQL integration | Real constraints, protected routines/permissions, freezing, transaction rollback, multi-office atomicity, deadline boundaries, concurrent duplicates, and submission versus completion/cancellation races. |
| Authorization/privacy | Cross-account/object access, suspended accounts, administrator without entitlement, active totals denied, cancelled choices denied, CLOSED VOTING data/log/export inspection, and OTP/session abuse controls. |
| Browser end-to-end | Both voting types; member/admin mobile setup; preview/confirmation; sign-in and expiry; review; acknowledged/duplicate/unknown submissions; completed/cancelled views; CSV/PDF download and failure recovery. |
| Accessibility | Automated axe checks plus manual keyboard, focus, screen-reader, zoom, contrast, and reduced-motion checks for core journeys. |
| PDF/CSV | Compare raw counts and identity fields with the shared result projection; maximum electorate; long/multiscript text; multi-page A4/grayscale; repeated headers/page numbers; complete named lists; no closed identities; failed rendering returns no success PDF. |
| Performance/recovery | 500-household dataset, 100 concurrent users, including contention on one vote; p95 page/API below two seconds and acknowledgement below three seconds, excluding email/network conditions; backup restore and reconciliation. |

Use real PostgreSQL for transaction tests, not SQLite or mocked repositories. Inject failures after participation insertion and midway through tally updates to prove rollback. Test a committed submission whose HTTP response is lost. Verify exact-deadline rejection using a controlled test harness and post-lock clock checks.

Run Chromium, Firefox, and WebKit automation, plus real mobile Safari, Android Chrome, and laptop-browser checks at the specified widths. Verify PDF downloads on physical phones as well as automated output parsing and visual print inspection.

Test that register edits preserve historical names and entitlements, type remains separate from lifecycle, every completed election office reconciles, and poll named responses match accepted participation. Privacy tests must examine API payloads, rendered HTML, logs, and ordinary database records, not just hidden UI elements.

## 14. Deployment and release approach

1. CI restores locked dependencies, runs formatting/lint checks, TypeScript checks, unit tests, real-database integration tests, production build, and focused browser tests. Review dependency advisories.
2. Build one immutable application image and promote the same image through staging and production.
3. Apply reviewed, versioned SQL migrations using deployment-only credentials. Test migrations and restoration in staging; do not run migrations automatically on every application start.
4. Use backward-compatible migrations when possible. Schedule maintenance for incompatible changes, preferably outside active votes. Do not deploy changes to submission/counting semantics during an active vote.
5. Configure HTTPS, secrets, database access, scheduler, backup expiry, alerts, and privacy-safe logging. Verify actual provider durability and backup settings.
6. Smoke-test access, protected endpoints, maintenance authentication, PDF generation, and dependency health with synthetic data before admitting real voting.
7. Start with one application instance and a bounded database pool. The database remains the shared coordination point; no in-memory session or lock is authoritative.

Production release requires approval of A1-A7 and providers, accessibility/mobile/PDF evidence, the performance targets, restore validation, count reconciliation, and the pilot's 90% unaided first-submission target measured without selections.

Any lost or duplicate vote, partial election, incorrect tally, unauthorized disclosure, or CLOSED VOTING identity-to-choice exposure blocks release. Roll back the application only when schema-compatible; never restore an old database merely to undo a deployment after votes have been accepted.

## 15. MVP versus future scalability

| MVP decision | Revisit only when justified |
|---|---|
| One RWA, single deployment, one managed database | Multi-RWA tenancy needs an explicit product decision, tenant-isolation model, and migration plan. |
| One instance and per-vote serialization | Add stateless replicas and tune pooling after measured demand; change locking only with equivalent integrity/race tests. |
| Database-backed sessions and rate limits | Introduce a separate shared store only after demonstrated database pressure. |
| Synchronous bounded PDF generation | Consider a private job queue and short-lived protected artifacts only if measured report size/concurrency requires them. |
| Scheduled HTTP maintenance | Use a dedicated worker only when maintenance volume warrants it; deadline enforcement remains in the submission transaction. |
| Aggregate-only CLOSED VOTING | Cryptographic verification or secrecy from operators requires a new approved architecture and threat model. |
| No AI, native apps, messaging, signatures, or complex election rules | Add only through separately approved requirements, not speculative infrastructure. |

Scale first through indexes, query plans, bounded payloads, pooling, and measured database/application capacity. Preserve frozen entitlements, exactly-once participation, deterministic results, and privacy boundaries before optimizing throughput.
