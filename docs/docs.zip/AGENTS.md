# Coding Agent Rules

## Scope and source of truth

These rules govern development of the single-RWA Voting and Polls application.

This file is intentionally stored under `docs`. Agents working elsewhere must explicitly load it if their tooling does not discover it; a nested `AGENTS.md` is not automatically a repository-wide instruction file.

Read the relevant governing documents before implementation:

| Document | Authority |
|---|---|
| [PRD.md](./PRD.md) | Product scope, voting behavior, assumptions A1-A7, and acceptance criteria |
| [DESIGN.md](./DESIGN.md) | Visual tokens, components, responsive behavior, accessibility, and interaction rules |
| [ARCHITECTURE.md](./ARCHITECTURE.md) | Stack, application boundaries, folder structure, privacy model, and operations |
| [DATABASE.md](./DATABASE.md) | Schema, constraints, protected routines, transactions, migrations, and retention |
| [API.md](./API.md) | Endpoints, validation, authentication, response contracts, errors, and integrations |

- Follow each document within its domain; implementation details must not override product or privacy requirements.
- Resolve material contradictions or missing decisions with the user before implementing affected behavior. Do not silently choose a weaker requirement.
- Treat A1-A7 as provisional until explicitly approved. Never fabricate approvals or bypass activation/release gates.
- These documents describe intended behavior, not proof that code or tests exist. Inspect the actual workspace before making claims.

## Inspect before changing

- Read existing instructions, affected code, callers, tests, configuration, and dependency manifests before editing.
- Search for existing components, services, schemas, utilities, and conventions before adding equivalents.
- Trace changes across relevant UI, service, database, API, export, and test surfaces; do not implement only the visible screen.
- Make the smallest complete change that addresses the task. Preserve unrelated behavior and user changes.
- Avoid speculative features, broad rewrites, generic frameworks, and unrelated cleanup. Obtain approval for architectural or product changes.

## Code quality and naming

- Follow established formatting, linting, naming, and localization conventions. When none exist, use descriptive `camelCase` for TypeScript values/functions, `PascalCase` for components/types, and `snake_case` for database objects.
- Keep functions focused and domain logic explicit. Prefer straightforward composition over inheritance, indirection, or premature abstraction.
- Use exact domain vocabulary: **OPEN VOTING** and **CLOSED VOTING** are types; Draft, Active, Completed, and Cancelled are separate statuses.
- Keep API/database enum values exact: `OPEN`, `CLOSED`, `DRAFT`, `ACTIVE`, `COMPLETED`, and `CANCELLED`.
- Centralize shared validation, normalization, counting, percentage rounding, authorization, and result projections. Do not duplicate business rules across screens or exports.
- Comment only non-obvious constraints or reasoning, especially locking, privacy, and recovery decisions.

## Project and folder structure

- Follow the modular monolith and suggested structure in [ARCHITECTURE.md](./ARCHITECTURE.md).
- Use `src/app` for Next.js pages, layouts, route groups, and HTTP handlers; `src/components/ui`, `votes`, and `admin` for reusable presentation.
- Keep design tokens/styles in `src/styles` and browser-safe contracts/validation in `src/shared`.
- Keep authentication, authorization, register, voting, results, exports, audit, database, email, observability, and configuration modules under their corresponding `src/server` features.
- Keep ordered SQL migrations in `db/migrations` and unit, integration, end-to-end, and fixture code under `tests`.
- Keep server-only modules out of client import graphs. HTTP handlers translate requests; services coordinate behavior; protected database operations enforce persistence integrity.
- Server-rendered pages call application services directly, not internal HTTP endpoints.
- Do not introduce separate frontend/backend deployments, microservices, extra packages, or dependency-injection/repository frameworks for the MVP.

## Component reuse and UI behavior

- Reuse existing buttons, fields, badges, messages, dialogs, tables, privacy notices, and application shell before creating variants.
- Use CSS Modules, shared design tokens, and native HTML controls. Do not add a large UI framework or replace approved styling without approval.
- Keep voting-type, lifecycle-status, and participation badges distinct.
- Preserve loading, empty, validation, denied-access, unknown-outcome, and failure states; never substitute misleading empty or success states.
- Require review and explicit confirmation before submission and consequential lifecycle actions.
- Keep unsent selections in page memory only, never URLs, browser storage, offline caches, or persisted drafts. Clear them after confirmed acceptance, sign-out, or access revocation.
- Meet WCAG 2.2 AA, semantic labeling, keyboard/focus behavior, reduced motion, and minimum 44-by-44 CSS-pixel touch targets.
- Verify member and administrator journeys at 320-430 CSS-pixel phone widths and 1280-1440 CSS-pixel laptop widths without page-level horizontal scrolling.

## Dependency management

- Use the approved TypeScript, React, Next.js App Router, supported Node.js LTS, PostgreSQL, `pg`, Zod, PDFKit, Vitest, Playwright, and axe stack unless an approved decision changes it.
- Inspect manifests and lockfiles before selecting a package manager or command. Use existing scripts rather than inventing commands.
- Add dependencies only for a demonstrated requirement that existing code or platform APIs cannot reasonably satisfy. Explain necessity and review maintenance, license, security, and runtime compatibility.
- Pin versions in the lockfile and keep it consistent with manifest changes. Use reproducible locked installs in CI.
- Do not install, upgrade, or replace unrelated packages.
- Do not add Redis, queues, object storage, external PDF rendering, analytics, AI, or speculative integrations for the MVP.

## Type safety and validation

- Maintain strict TypeScript checking. Avoid `any`, unchecked assertions, non-null assertions, and suppressed diagnostics; use explicit types and narrowing.
- Treat external input as untrusted `unknown`. Validate server-side with shared Zod contracts and protected database checks; browser validation is advisory.
- Reject unknown fields, malformed identifiers, invalid enums, unsupported filters, and mixed ballot shapes. Match API bounds and database constraints.
- Use discriminated contracts for voting types and lifecycle-dependent data. Distinguish omitted PATCH fields from documented nullable fields.
- Preserve PostgreSQL `bigint` precision. API counts and audit IDs are decimal strings; do not silently coerce them into JavaScript numbers.
- Use the shared half-up percentage policy: two decimal places as strings, or `null` for a zero denominator.
- Store instants in UTC and display the frozen IANA timezone. Require unambiguous offset-bearing timestamps at API boundaries.

## Error handling and recovery

- Follow [API.md](./API.md) status codes and `{ error, requestId }` envelopes, with stable codes, safe messages, and allowlisted field/context information.
- Handle expected domain failures explicitly. Unexpected faults must produce safe errors and restricted operational alerts.
- Never swallow errors, fabricate totals, silently repair invariants, or return success-shaped fallbacks.
- Never expose stack traces, SQL, provider responses, submitted sensitive values, or CLOSED selections in errors.
- A submission succeeds only after durable commit. Disable repeated clicks for UX, but do not rely on the browser for correctness.
- For lost responses or uncertain outcomes, query participation before offering a deliberate retry. If status is unavailable, show an explicit unknown state; do not claim acceptance or rejection.
- Do not automatically retry client mutations or uncertain database commits. Any internal retry must restart a whole transaction only after a known rollback condition.
- Keep email and export failures independent from accepted voting records. A generic OTP acknowledgement does not prove delivery.
- Render complete CSV/PDF content before successful download headers; never return a partial report as successful.

## Security, secrets, and privacy

- Never expose credentials, tokens, codes, real environment values, resident data, or ballot payloads in source control, chat output, logs, fixtures, screenshots, or third-party tools.
- Use approved secret management, ignored local environment files, and placeholder-only examples. Never use browser-visible prefixes for secrets.
- Validate required configuration at startup and fail clearly on missing or unsafe settings. Separate local, test, staging, and production credentials/data.
- Use synthetic identities and a local mail sink or approved staging recipients. Never copy production registers, ballots, or backups into development.
- Enforce current session/account state, role, and object-level authorization in services and protected database entry points on every access. UI checks and UUID possession are not authorization.
- Follow OTP expiry/attempt limits, digest storage, secure opaque session cookies, revocation, exact-origin checks, CSRF protection, and PostgreSQL-backed shared rate limits in [API.md](./API.md).
- Use HTTPS, validated database TLS, restrictive security headers, and explicitly trusted proxies. Do not enable permissive credentialed CORS.
- Disable request-body, SQL bind-parameter, cookie, code, email-content, session-replay, and network-payload capture across application and infrastructure tooling.
- Log only allowlisted operational events and safe support IDs. Audit administrative changes atomically without selections or authentication material.
- CLOSED VOTING stores aggregate counters, never individual ballots, cross-office ballot IDs, selection receipts, per-response counter history, or identity-to-choice mappings.
- Never expose active tally snapshots, differencing tools, or CLOSED selection-retrieval endpoints. Do not claim cryptographic anonymity or secrecy from privileged infrastructure operators.

## Database and API access

- Follow [DATABASE.md](./DATABASE.md) and [API.md](./API.md) exactly; do not invent endpoints, fields, tables, election rules, or shortcuts around protected operations.
- Access PostgreSQL only through server-side `pg`, parameterized SQL, bounded pools, and approved routines. Browsers never connect directly.
- Use separate deployment, protected-routine-owner, runtime, and maintenance capabilities. Runtime has no direct base-table reads/writes, DDL, grants, or unrestricted tally access.
- Protected entry points validate session authority; never trust caller-supplied account IDs, household IDs, roles, or database context variables as identity.
- Preserve reviewed routine grants, fixed trusted search paths, schema-qualified objects, and revoked public execution. Do not introduce RLS as a substitute for the documented MVP boundary.
- Lock the parent vote first and follow the documented lock order. Revalidate session, account, frozen entitlement, lifecycle, ballot ownership, and post-lock database time inside the submission operation.
- Atomically insert participation and either one OPEN response or all CLOSED office counter increments. Enforce uniqueness, deferred consistency checks, and complete rollback on failure.
- Reject admission at or after the frozen deadline using `clock_timestamp()` after locks, not a browser clock or transaction-start timestamp.
- Freeze configuration, electorate identities, deadline, RWA metadata, and policy versions at activation. Register changes never transfer existing entitlements or rewrite history.
- Permit only Draft-to-Active, Active-to-Completed, and Active-to-Cancelled transitions. Never reopen terminal votes, extend frozen deadlines, edit submissions, or manually change results.
- Commit overdue-state reconciliation when rejecting an overdue submission; do not accidentally roll it back as an ordinary domain rejection.
- Keep transactions short; perform email delivery and report rendering outside them.
- Publish results only after completion and invariant verification. Use one consistent authoritative projection for pages, APIs, CSV, and PDF.
- OPEN exports include the complete frozen named-response list without email addresses; CLOSED exports contain aggregates only, never voter/household lists. Exports are not limited to the current UI page.
- Preserve exact response envelopes, decimal-string counts, keyset pagination, download schemas, and `private, no-store` protections. Return explicit allowlisted projections, not database rows.
- Use ordered, immutable, versioned SQL migrations. Test fresh installs and upgrades; never run migrations on every application startup or rewrite applied migrations.
- Apply only approved lifecycle-aware retention. Never delete participation while submissions remain possible or treat unset retention as unlimited.

## Testing and verification

- Add or update tests for every changed behavior and regression. Use existing tooling; do not introduce a parallel test framework.
- Run focused tests first, then required lint, type checks, integration/browser checks, and production build appropriate to the change. Report actual commands, outcomes, and checks not run.
- Use real PostgreSQL for constraints, routines, privileges, locking, durability, and transaction tests; mocks or SQLite are not substitutes.
- Cover concurrent duplicates, multi-office rollback, exact deadlines, lock-wait expiry, completion/cancellation races, suspension, frozen identities, and committed submissions with lost HTTP responses.
- Verify authorization/privacy through API payloads, rendered HTML, ordinary stored records, logs, audits, and exports, not merely hidden controls.
- Test zero turnout, all abstentions, ties, denominators, rounding, and exact page/API/CSV/PDF agreement.
- Test complete exports with the maximum electorate, long/multiscript text, multi-page A4/grayscale layout, repeated headers, page numbers, and rendering failures.
- Use Playwright across Chromium, Firefox, and WebKit, axe checks, and manual keyboard/focus/screen-reader checks where required. Do not claim automated checks prove full accessibility.
- Require real mobile Safari, Android Chrome, laptop, and physical-phone PDF evidence before release.
- Validate the approved 500-household/100-concurrent-user scale, including same-vote contention: p95 page/API below two seconds and acknowledgement below three seconds, excluding email/network conditions.
- Verify backup restoration, accepted-data completeness, and reconciliation before launch. Do not resume an election when acknowledged submissions may be missing.
- Documentation-only changes need no application test run unless documentation tooling exists. Never claim unexecuted tests passed.

## Documentation

- Update directly affected product, design, architecture, database, API, configuration, migration, and operational documentation with behavior changes.
- Keep contracts synchronized across documents and implementation; link to authoritative detail rather than duplicating it.
- Record approved deviations, privacy limits, migration/recovery steps, and required operational settings. Clearly distinguish proposed, implemented, tested, and approved behavior.
- Do not describe PDFs as signatures, legal certification, spending authorization, or automatic replacements for legally required signatures.
- Do not create unsolicited planning documents or claim documentation alone satisfies acceptance criteria.

## Git and change discipline

- Inspect repository status when Git is available. Preserve existing user changes and keep the patch limited to the requested task.
- Do not commit, push, amend, reset, discard files, rewrite history, or perform destructive database operations without explicit authorization.
- Never stage secrets, real environment files, resident data, generated reports, database dumps, or unrelated changes.
- Keep authorized commits coherent and descriptive; include directly related tests, documentation, migrations, and lockfile changes.
- Do not change submission/counting semantics during active voting. Prefer backward-compatible migrations and coordinate incompatible changes through approved maintenance.
- Never restore an old database as deployment rollback after accepted submissions. Use a schema-compatible application rollback or reviewed forward fix.
- Before handoff, state the change, verification evidence, unresolved risks, and approval/release blockers. Do not present partial implementation as production-ready.
- Any lost/duplicate participation, partial submission, incorrect tally, unauthorized disclosure, or CLOSED identity-to-choice exposure blocks release.
