# DESIGN.md — RWA Voting and Polls

## 1. Purpose and product context

This document is the visual and UX source of truth for the RWA Voting and Polls application. It translates the product requirements into reusable design rules for residents and administrators using phones or laptops.

The product supports two **voting types**:

- **OPEN VOTING** — responses are attributable. After voting is completed, eligible members and administrators can see who chose each option.
- **CLOSED VOTING** — choices are private from voters and administrators. Results show aggregates only.

Voting type is distinct from lifecycle status. **Draft**, **Active**, **Completed**, and **Cancelled** describe a vote’s lifecycle, not its type. Keep these concepts visually and verbally distinct on every screen.

Design for a trustworthy civic process: make eligibility, deadlines, privacy, consequences, and next steps clear. Avoid decorative or promotional treatments that could make voting feel casual or obscure important information.

## 2. Visual direction and principles

### Visual direction

Use a calm, legible, record-oriented interface: warm neutral surfaces, dark ink-like text, and restrained civic green for primary actions and confirmed states. The product should feel dependable and straightforward rather than like a marketing site or a generic SaaS dashboard.

Use whitespace and clear grouping to make dense information easier to understand. Favor readable text, strong labels, simple borders, and familiar controls over illustrations, gradients, decorative charts, or motion-heavy effects.

### Principles

1. **Make the decision understandable.** Show the vote title, type, status, deadline, and relevant instructions where a person needs them.
2. **Explain privacy before participation.** Present the correct type-specific notice before selection and again before final submission.
3. **Require deliberate action for consequential changes.** Review and confirmation are part of ballot submission; lifecycle actions require explicit confirmation.
4. **Never imply more certainty than the system can provide.** Do not show success until acknowledged. When a submission outcome is uncertain, guide the user to check participation status before retrying.
5. **Keep private choices private.** Closed-voting interfaces, results, exports, and notifications must not expose or imply identity-to-choice links.
6. **Use consistent language and visual meaning.** Do not use the same treatment for voting type and lifecycle status.
7. **Prioritize mobile completion.** Voting and administration must both work on narrow touch screens without horizontal page scrolling.
8. **Be accessible by default.** Every visual cue has an accessible text or programmatic equivalent.

## 3. Color system

Use color to communicate meaning, never as the only indicator. Pair status and actions with visible text and, where useful, an icon.

| Token | Value | Use |
|---|---:|---|
| `canvas` | `#F7F6F2` | Application page background |
| `surface` | `#FFFFFF` | Cards, forms, dialogs, and result panels |
| `surface-muted` | `#F0EFEA` | Secondary panels, read-only summaries, table headers |
| `ink` | `#202925` | Primary text and headings |
| `ink-muted` | `#53615A` | Supporting text, metadata, helper text |
| `border` | `#D8DDD7` | Dividers, input borders, card boundaries |
| `brand` | `#245B46` | Primary buttons, links, active navigation |
| `brand-hover` | `#194632` | Hover and pressed states for primary actions |
| `brand-soft` | `#E8F1EB` | Subtle selected or informational backgrounds |
| `focus` | `#1B66C9` | Keyboard focus indicator |
| `success` | `#286343` | Successful completion and confirmed states |
| `success-soft` | `#EAF3EC` | Success message backgrounds |
| `warning` | `#805600` | Deadline reminders and caution |
| `warning-soft` | `#FFF4D8` | Warning message backgrounds |
| `danger` | `#A12828` | Errors, cancellation, destructive actions |
| `danger-soft` | `#FBEDEC` | Error message backgrounds |

Maintain WCAG 2.2 AA contrast for text, controls, and focus indicators. Verify contrast for each actual foreground/background pairing, including muted text and status colors. Do not use color alone to differentiate options, statuses, results, or errors.

### Voting type and lifecycle appearance

- Display **OPEN VOTING** and **CLOSED VOTING** as explicit text labels. Use a neutral outlined type badge; do not rely on color to convey privacy.
- Display lifecycle status separately using a consistent status badge and text label:
  - **Draft** — neutral gray.
  - **Active** — brand green, with text.
  - **Completed** — dark neutral or success treatment, with text.
  - **Cancelled** — danger treatment, always accompanied by “Results not valid.”
- Do not use “anonymous” or “named poll” as replacement labels for the confirmed voting types.
- Do not show choice totals or provisional result visualizations while a vote is active.

## 4. Typography

Use a robust system sans-serif stack so text remains readable and loads quickly across supported browsers. Use the same type family throughout the application and generated results PDF.

| Style | Suggested size and line height | Use |
|---|---|---|
| Page title | 28–32 px / 1.2 | Main page heading |
| Section heading | 20–24 px / 1.3 | Major content groups |
| Card or subsection heading | 16–18 px / 1.35 | Cards, forms, result groups |
| Body | 16 px / 1.5 | Instructions, descriptions, default content |
| Supporting text | 14 px / 1.45 | Helper text, metadata, table details |
| Compact label | 14 px / 1.35, medium weight | Field labels and compact controls |

Use sentence case for headings, buttons, and navigation. Reserve uppercase for the fixed **OPEN VOTING** and **CLOSED VOTING** labels where needed to reinforce the product’s vocabulary. Avoid long passages in all caps, overly light font weights, and small text for critical information.

Use tabular numerals for counts, turnout, and percentages when available. Keep percentages with their denominator visible wherever that context is needed.

## 5. Spacing, layout, and surfaces

Use a consistent 4 px spacing base. Common spacing steps are 4, 8, 12, 16, 24, 32, and 48 px.

- Keep related field labels, controls, and helper text close together; use larger spacing between distinct sections.
- Use a content maximum width of approximately 1120 px on desktop, with narrower reading widths for long instructions and ballot content.
- Give mobile screens 16 px minimum side padding. At larger widths, increase page gutters to 24–32 px.
- Use simple rectangular surfaces with subtle borders. Reserve shadows for overlays such as dialogs, not routine cards.
- Prefer a single clear content column for member journeys. Use multi-column layouts only when they improve scanning, such as an administration list with a supporting summary.
- Avoid nested cards. Use headings, spacing, and dividers to establish hierarchy.
- Keep tables and long lists within their own responsive container; do not allow them to create page-level horizontal scrolling.

## 6. Reusable components

### Buttons

- **Primary:** one prominent action per view, such as “Review selections,” “Submit vote,” or “Activate vote.”
- **Secondary:** supporting actions such as “Save draft,” “Cancel,” or “Back.”
- **Destructive:** use the danger treatment for consequential actions such as cancelling an active vote. Pair with an explicit confirmation.
- **Text link:** use for navigation or low-emphasis actions, not as the only way to complete a critical workflow.

Use clear, action-specific labels. Buttons must have visible hover, pressed, focus, disabled, and loading states. Use a minimum 44 × 44 CSS-pixel touch target. Do not use vague labels such as “OK” or “Submit” when a more specific label is possible.

### Cards and list rows

Use cards for distinct votes, summary groups, and important actions. A vote list item should show its title, voting type, lifecycle status, deadline or completion date, and the current member’s participation state where applicable. Make the primary destination obvious without making the entire row an inaccessible or ambiguous control.

### Status messages

Use a consistent message component with an icon or other non-color indicator, a short heading when needed, and clear explanatory text. Place the message close to the relevant content. Provide recovery steps for errors where possible.

### Badges

Use compact badges for voting type, lifecycle status, and participation state. Keep badge text visible and specific. Do not combine voting type and lifecycle status into a single badge.

### Tables and result summaries

Use clear column headers, adequate row spacing, and right-aligned numeric values. Keep labels and values understandable on narrow screens by converting rows into stacked label/value groups or using a contained horizontal scroller with an accessible name. Do not truncate names, options, totals, or other decision-relevant information.

### Dialogs and confirmations

Use dialogs only for consequential confirmation or focused tasks. Clearly state the action, its effect, and whether it can be undone. Provide a clear cancel action. On mobile, use a full-width or near-full-width dialog that remains within the viewport and keeps its actions reachable.

## 7. Navigation and information architecture

### Member navigation

Keep navigation focused on the member’s voting tasks:

- **Votes** — eligible current and past votes.
- **Account / Sign out** — registered account information and session exit.

Do not expose unrelated community content or allow an unauthenticated visitor to discover members, ballots, or results.

On phones, use a simple compact header and a clearly labeled, touch-accessible navigation pattern. Do not hide essential voting actions inside a complex menu.

### Administration navigation

Provide clear entry points for:

- **Votes** — draft, active, completed, and cancelled votes.
- **Households** — eligible register and representative assignments.
- **Audit history** — administrative actions and reasons.

Administration may share the same application shell as the member experience, but administrative capabilities must be visually identifiable and access-controlled. Do not make administrator status imply voter eligibility.

### Navigation behavior

Use descriptive page titles and breadcrumbs for deeper administration tasks. Preserve entered draft data when navigating within a setup flow where feasible. Always provide a visible route back or a clear “Cancel”/“Back” action. Avoid changing the meaning or location of navigation across member and administrator screens.

## 8. Forms and ballot UX

### General form rules

- Use persistent, visible labels. Do not use placeholders as the only labels.
- Group related inputs and explain format requirements beside the relevant field.
- Mark required fields clearly and provide specific validation messages next to the affected input.
- Preserve valid entered data when correcting validation errors.
- Clearly distinguish editable fields from read-only or frozen values.
- For long forms, use titled sections and a clear progress or section structure rather than one uninterrupted field list.

### Voting setup

Let administrators explicitly choose **OPEN VOTING** or **CLOSED VOTING** and explain the difference before configuration continues. Keep the selected type visible throughout draft editing and preview.

For an election, group offices with their candidates and explicit **Abstain** option. For a poll, show the question and its single-choice options. Explain that activation freezes the voting type, ballot content, electorate, representative assignments, and deadline. Provide a complete preview of the resident ballot and privacy notice before activation.

### Resident ballot

Present the vote title, voting type, lifecycle status, deadline with timezone, and relevant instructions before the selection controls.

- **CLOSED VOTING:** Explain that administrators and voters cannot see how an individual voted. Do not provide a receipt or later ballot view that reveals selections.
- **OPEN VOTING:** Before selection and submission, explain that the voter’s name, household identifier, and response will appear in completed results and downloadable records.

Use native, keyboard-operable single-choice controls. Make the selected state clear without relying solely on color. For elections, organize choices by office and make the **Abstain** option explicit.

Provide a review step that summarizes all selections before final submission. State that submission is final and cannot be edited or withdrawn. For elections, confirm all offices as one complete submission. Disable repeat submission while the request is in progress and acknowledge success only after the complete submission is confirmed.

## 9. Loading, empty, and error states

### Loading

- Use stable skeletons or progress indicators while loading lists and results; avoid layout shifts.
- During submission, show a clear “Submitting vote…” state, disable repeat submission, and do not show success prematurely.
- During PDF generation, show progress and prevent duplicate generation requests.
- Do not display provisional totals or imply that a vote has been counted before acknowledgement.

### Empty states

Write specific empty-state messages for:

- No current votes available to the member.
- No eligible households in the register.
- No votes in an administration list.
- An incomplete draft that cannot be activated.
- Zero turnout after completion.
- No named responses in an OPEN VOTING result.

Explain why the state is empty and what the user can do next. Zero turnout is not a winning result. For CLOSED VOTING, never use an empty-state design that implies individual responses could be inspected.

### Errors and recovery

Use plain language that names what happened and gives the next safe step. Cover invalid or expired sign-in codes, email delivery failure, unauthorized or ineligible access, form validation, duplicate submission, completed or cancelled votes, network/server errors, and export failures.

If submission outcome is uncertain, direct the user to check participation status before offering a retry. Do not claim the vote failed without checking its status. Keep unsent selections in page memory only. A PDF failure must leave completed results visible and offer a retry without changing results or resubmitting a ballot.

## 10. Interactions and animation

Use restrained, fast transitions for state changes, such as button feedback, menu opening, or expanding a section. Keep motion short and subtle; do not animate vote totals, ballot selections, or status in a way that could suggest provisional results or influence a voter.

Provide immediate visible feedback for selection, save, submission progress, and validation. Require explicit confirmation for activating, completing early, or cancelling a vote. Cancellation must request a reason and clearly state that results will be marked invalid.

Support reduced-motion preferences. Do not rely on hover for essential information or actions. Avoid auto-dismissed messages for errors or important submission acknowledgements.

## 11. Responsive behavior

Design and test for 320–430 CSS-pixel phone widths and laptop widths of 1280–1440 CSS pixels.

- Start with a single-column mobile layout and expand into wider layouts only when useful.
- Keep primary actions visible and reachable without overlapping content. On long mobile forms, a sticky action area may be used only if it does not obscure fields, focus, or validation messages.
- Do not require hover, a mouse, or a wide viewport for member or administrator tasks.
- Adapt tables and long response lists to narrow screens without clipping names, options, or totals.
- Keep dialogs, menus, and date/time controls within the viewport.
- Ensure text wraps naturally and controls do not create page-level horizontal scrolling.
- Verify sign-in, voting, review, confirmation, results, administration, and PDF download on mobile Safari, Android Chrome, and laptop browsers.

## 12. Accessibility requirements

Meet WCAG 2.2 AA for core journeys.

- Use semantic page landmarks, one clear page-level heading, logical heading order, and descriptive accessible names.
- Ensure all workflows are operable by keyboard with visible focus indicators and a logical focus order.
- Provide sufficient contrast for text, controls, boundaries, status indicators, and focus states.
- Use at least 44 × 44 CSS-pixel touch targets for interactive controls.
- Associate labels, instructions, and validation messages programmatically with their form controls.
- Announce loading, errors, and submission acknowledgements appropriately to assistive technology without unexpectedly moving focus.
- Do not rely on color, position, or icon alone to explain voting type, status, selection, or errors.
- Make dialogs keyboard-accessible, move focus appropriately when opened, and return focus when closed.
- Ensure zoom and text resizing do not hide content or actions.
- Use accessible tables with headers and preserve reading order in responsive layouts.
- Respect reduced-motion settings.
- Keep type-specific privacy notices readable and available before final submission.

## 13. Page-level layout guidance

### Sign-in and code verification

Keep the screen focused on registered-member email entry and one-time-code verification. Explain that access is for registered members; do not offer public self-registration. Provide clear expired-code recovery, delivery-failure guidance, and access-denied states without exposing register details.

### Member home

Show eligible current votes first, with type, separate lifecycle status, deadline, and the member’s own participation state. Keep completed votes accessible for results when authorized. Do not show other members’ participation while a vote is active.

### Vote detail and ballot

Show the title, type and privacy notice, status, deadline with timezone, and instructions above the ballot. Keep selection controls grouped by question or office. Include review, final confirmation, and an acknowledgement state. Never show live choice totals.

### Results

Show completion context, eligible households, submitted ballots, turnout, and final counts. Label percentage denominators. For elections, show abstentions separately; report ties as ties and show no winner when there were no ballots. For OPEN VOTING, show the authorized named-response list after completion. For CLOSED VOTING, show aggregates only. Keep CSV and **Download PDF** actions available only for completed votes and only to authorized users.

### Administration vote list

Make it easy to distinguish drafts needing attention, active votes, and completed or cancelled records without conflating lifecycle status with voting type. Show the next relevant action for each draft or active vote. Do not expose closed-voting selections in administration summaries or participation monitoring.

### Draft editor and preview

Organize configuration into clear sections: voting type, ballot content, electorate, deadline, and preview. Identify validation issues close to the affected section. Show the privacy notice and complete resident-facing ballot in preview. Activation must be a deliberate final action after validation and preview.

### Household register

Present household identifier, representative, registered email, and eligibility in a readable, manageable list. Provide clear add/edit and validation feedback. Explain that register changes after activation do not alter the frozen electorate or representative assignments for that vote.

### Lifecycle confirmations and audit history

For activation, early completion, and cancellation, summarize the consequences before confirmation. Cancellation requires a reason and must communicate that results are invalid. Keep audit history readable and factual, showing actor, action, affected record, timestamp, and reason where applicable; never include CLOSED VOTING choices.

## 14. PDF and print presentation

The downloaded PDF is a voting record, not a digital signature or legal certification. Match the application’s authoritative completed results and use the same typography and restrained color palette, with a grayscale-safe layout.

Format for legible A4 portrait printing. Include the required RWA and vote details, voting type, timestamps with timezone, counts, turnout, percentage denominators, abstentions, ties, no-votes, and generation time. OPEN VOTING reports include the complete authorized respondent name, household identifier, and choice list, but omit email addresses. CLOSED VOTING reports contain aggregates only and must never contain voter or household lists or identity-to-choice mappings.

Repeat table headers across pages, wrap long text, include page numbers, and prevent clipping or truncation. A failed PDF generation or download must not change a vote or its results.
